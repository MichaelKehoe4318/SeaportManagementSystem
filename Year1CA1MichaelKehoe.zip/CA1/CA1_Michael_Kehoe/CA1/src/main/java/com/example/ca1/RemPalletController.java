package com.example.ca1;

import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceBox;

import java.io.IOException;

public class RemPalletController {

    // Fields
    public ChoiceBox<Pallet> selectedDelPallet;

    public void delPallet(ActionEvent actionEvent) throws IOException {
        // Get target pallet from choicebox
        Pallet palletToDelete = selectedDelPallet.getValue();

        if (palletToDelete != null) {
            // Traverse through the lists to remove the pallet
            FunkyList<Port>.FunkyNode<Port> ptemp = Port.portsList.head;
            while (ptemp != null) {
                FunkyList<CargoShip>.FunkyNode<CargoShip> stemp = ptemp.getContents().dockedShips.head;
                while (stemp != null) {
                    FunkyList<Container>.FunkyNode<Container> ctemp = stemp.getContents().shipContainers.head;
                    while (ctemp != null) {
                        ctemp.getContents().containerPallets.remove(palletToDelete); // Remove the pallet
                        ctemp = ctemp.next;
                    }
                    stemp = stemp.next;
                }
                ptemp = ptemp.next;
            }
            selectedDelPallet.getItems().remove(palletToDelete); // Remove from ChoiceBox
        } else {
            System.out.println("No pallet selected.");
            //No pallet selected
        }
    }

    public void initialize() {
        FunkyList<Port>.FunkyNode<Port> ptemp = Port.portsList.head;
        while (ptemp != null) {
            FunkyList<CargoShip>.FunkyNode<CargoShip> stemp = ptemp.getContents().dockedShips.head;
            while (stemp != null) {
                FunkyList<Container>.FunkyNode<Container> ctemp = stemp.getContents().shipContainers.head;
                while (ctemp != null) {
                    FunkyList<Pallet>.FunkyNode<Pallet> pltemp = ctemp.getContents().containerPallets.head;
                    while (pltemp != null) {
                        selectedDelPallet.getItems().add(pltemp.getContents());
                        pltemp = pltemp.next;
                    }
                    ctemp = ctemp.next;
                }
                stemp = stemp.next;
            }
            ptemp = ptemp.next;
        }
    }

    // Method to go back to the main menu
    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}
