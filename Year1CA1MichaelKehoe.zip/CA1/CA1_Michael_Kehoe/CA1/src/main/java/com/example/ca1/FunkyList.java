package com.example.ca1;

public class FunkyList<F> {
    public FunkyNode<F> head = null;

    public void addElement(F e) {
        FunkyNode<F> fn = new FunkyNode<>();
        fn.setContents(e);
        fn.next = head;
        head = fn;
    }

    public void remove(F e) {
        FunkyNode<F> temp = head, temp2 = null;
        if (head.getContents().equals(e)) {
            head = head.next;
            return;
        }
        while (temp != null && !temp.getContents().equals(e)) {
            temp2 = temp;
            temp = temp.next;
        }
        if (temp != null) {
            temp2.next = temp.next;
        }
    }
        public void clear () {
            head = null;
        }

    public int getSize() {
        int length = 0;
        FunkyNode<F> selected = head;
        while (selected != null) {
            length++;
            selected = selected.next;
        }
        return length;
    }

    class FunkyNode<N> {
            public FunkyNode<N> next = null;
            private N contents;

            public N getContents() {
                return contents;
            }

            public void setContents(N c) {
                contents = c;
            }
        }
    }
