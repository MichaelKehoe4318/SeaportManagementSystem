package com.example.ca1;

public class CargoShip {

    public FunkyList<Container> shipContainers = new FunkyList<>();

    //Fields
    String name,flagState,pic;
    int identifier;
    public static CargoShip head;

    //Getters
    public String getShipName(){return name;}

    public int getId(){return identifier;}

    public String getFlagState(){return flagState;}

    public String getPic(){return pic;}

    public FunkyList<Container> getShipContainers() {
        return shipContainers;
    }

    //Setters
    public void setName(String name) {this.name = name;}

    public void setIdentifier(int identifier) {this.identifier = identifier;}

    public void setFlagState(String flagState) {this.flagState = flagState;}

    public void setPic(String pic) {this.pic = pic;}

    //Object
    public CargoShip(String name, int id, String flag, String picture){
        this.name=name;
        identifier=id;
        flagState=flag;
        pic=picture;
    }

    public String toString(){return "Cargo ship name:" +name+", Ship identifier:"+identifier+", Flag State:"+flagState+", Picture:"+ pic;
    }

    public void addContainer(Container cont){
        shipContainers.addElement(cont);
    }

//Search function, allows locating a cargoship within thr list through name.
    public static CargoShip getCargoShipByName(String value) {
        FunkyList<Port>.FunkyNode<Port> ptemp=Port.portsList.head;
        while(ptemp!=null) {
            FunkyList<CargoShip>.FunkyNode<CargoShip> temp = ptemp.getContents().dockedShips.head;
            while (temp != null && !temp.getContents().getShipName().equals(value))
                temp = temp.next;
            if (temp != null)
                return temp.getContents();
            ptemp=ptemp.next;
        }
        return null;
    }


    //Search function, allows you to search for a cargoship by name from within a specific port
    private CargoShip getCargoShipByNameFromPort(String value, Port port1) {
        FunkyList<CargoShip>.FunkyNode<CargoShip> temp = port1.dockedShips.head;
        while (temp != null && !temp.getContents().getShipName().equals(value))
            temp = temp.next;
        if (temp != null)
            return temp.getContents();
        return null;
    }
}
