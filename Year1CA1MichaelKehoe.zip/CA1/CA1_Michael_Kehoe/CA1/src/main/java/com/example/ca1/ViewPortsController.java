package com.example.ca1;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;

import java.io.IOException;

public class ViewPortsController {
    public ListView viewPorts;
    public Button homeButton;

    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }

    public void initialize() {
        FunkyList<Port>.FunkyNode<Port> ptemp = Port.portsList.head;
        while (ptemp != null) {
            viewPorts.getItems().add(ptemp.getContents());
            ptemp = ptemp.next;
        }
    }
}
