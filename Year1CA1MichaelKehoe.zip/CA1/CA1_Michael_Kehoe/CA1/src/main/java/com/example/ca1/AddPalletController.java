package com.example.ca1;

import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import java.io.IOException;

public class AddPalletController {

    // Fields
    public TextField palletGoods;
    public TextField palletQuantity;
    public TextField palletValue;
    public TextField palletWeight;
    public TextField palletTotSize;
    public ChoiceBox<Container> selectedContainer;

    // Creates pallet in selected container
    public void CreatePallet(ActionEvent actionEvent) {
        // Create a new Pallet object with the provided details
        Pallet pallet1 = new Pallet(
                palletGoods.getText(),
                Integer.parseInt(palletQuantity.getText()),
                Integer.parseInt(palletValue.getText()),
                Integer.parseInt(palletWeight.getText()),
                Integer.parseInt(palletTotSize.getText())
        );

        // Retrieve the selected container directly from the ChoiceBox
        Container cont = selectedContainer.getValue();
        if (cont != null) {
            cont.containerPallets.addElement(pallet1);
        } else {
            System.out.println("Container not found.");
            // Handle the case when the container is not found
        }
    }

    // Fills dropdowns with the list of containers
    public void initialize() {
        FunkyList<Port>.FunkyNode<Port> ptemp = Port.portsList.head;
        while (ptemp != null) {
            FunkyList<CargoShip>.FunkyNode<CargoShip> stemp = ptemp.getContents().dockedShips.head;
            while (stemp != null) {
                FunkyList<Container>.FunkyNode<Container> ctemp = stemp.getContents().shipContainers.head;
                while (ctemp != null) {
                    selectedContainer.getItems().add(ctemp.getContents());
                    ctemp = ctemp.next;
                }
                stemp = stemp.next;
            }
            ptemp = ptemp.next;
        }
    }

    // Returns user to main menu
    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }

    // Retrieves a container by its code
    public Container getContainerByCode(int value) {
        FunkyList<Port>.FunkyNode<Port> ptemp = Port.portsList.head;
        while (ptemp != null) {
            // Check containers on docked ships
            FunkyList<CargoShip>.FunkyNode<CargoShip> stemp = ptemp.getContents().dockedShips.head;
            while (stemp != null) {
                FunkyList<Container>.FunkyNode<Container> ctemp = stemp.getContents().shipContainers.head;
                while (ctemp != null) {
                    if (ctemp.getContents().getCode() == value)
                        return ctemp.getContents();
                    ctemp = ctemp.next;
                }
                stemp = stemp.next;
            }

            // Check containers on shore in the port
            FunkyList<Container>.FunkyNode<Container> pctemp = Port.shoreContainer.head;
            while (pctemp != null) {
                if (pctemp.getContents().getCode() == value)
                    return pctemp.getContents();
                pctemp = pctemp.next;
            }

            ptemp = ptemp.next;
        }
        return null; // Container not found
    }
}
