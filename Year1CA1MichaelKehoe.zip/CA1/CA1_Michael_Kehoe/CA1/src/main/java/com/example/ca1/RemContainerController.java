package com.example.ca1;

import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceBox;
import java.io.IOException;

public class RemContainerController {

    public ChoiceBox<Container> selectedDelContainer;

    public void delContainer(ActionEvent actionEvent) {
        Container contToDelete = selectedDelContainer.getValue();

        if (contToDelete != null) {
            FunkyList<Port>.FunkyNode<Port> ptemp = Port.portsList.head;
            while (ptemp != null) {
                FunkyList<CargoShip>.FunkyNode<CargoShip> stemp = ptemp.getContents().dockedShips.head;
                while (stemp != null) {
                    FunkyList<Container> shipContainers = stemp.getContents().getShipContainers();
                    if (shipContainers != null) {
                        shipContainers.remove(contToDelete);
                    }
                    stemp = stemp.next;
                }

                FunkyList<Container> shoreContainers = Port.shoreContainer;
                if (shoreContainers != null) {
                    shoreContainers.remove(contToDelete);
                }

                ptemp = ptemp.next;
            }

            selectedDelContainer.getItems().remove(contToDelete);
        } else {
            System.out.println("No container selected.");
        }
    }

    public void initialize() {
        FunkyList<Port>.FunkyNode<Port> ptemp = Port.portsList.head;
        while (ptemp != null) {
            FunkyList<CargoShip>.FunkyNode<CargoShip> stemp = ptemp.getContents().dockedShips.head;
            while (stemp != null) {
                FunkyList<Container>.FunkyNode<Container> ctemp = stemp.getContents().shipContainers.head;
                while (ctemp != null) {
                    selectedDelContainer.getItems().add(ctemp.getContents());
                    ctemp = ctemp.next;
                }
                stemp = stemp.next;
            }

            FunkyList<Container>.FunkyNode<Container> pctemp = Port.shoreContainer.head;
            while (pctemp != null) {
                selectedDelContainer.getItems().add(pctemp.getContents());
                pctemp = pctemp.next;
            }

            ptemp = ptemp.next;
        }
    }

    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}

