package com.example.ca1;

import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceBox;
import java.io.IOException;

public class RemCargoShipController {

    public ChoiceBox<CargoShip> selectedDelCShip;
    public ChoiceBox<Port> selectedPort;

    public void delCShip(ActionEvent actionEvent) {
        CargoShip shipToDelete = selectedDelCShip.getValue();
        if (shipToDelete != null) {
            Port selectedPort = this.selectedPort.getValue();
            if (selectedPort != null) {
                FunkyList<CargoShip>.FunkyNode<CargoShip> stemp = selectedPort.getDockedShips().head;
                while (stemp != null) {
                    if (stemp.getContents().equals(shipToDelete)) {
                        selectedPort.getDockedShips().remove(shipToDelete);
                        selectedDelCShip.getItems().remove(shipToDelete);
                        return;
                    }
                    stemp = stemp.next;
                }
            } else {
                System.out.println("No port selected.");
            }
        } else {
            System.out.println("No cargo ship selected.");
        }
    }

    public void initialize() {
        FunkyList<Port>.FunkyNode<Port> ptemp = Port.portsList.head;
        while (ptemp != null) {
            FunkyList<CargoShip>.FunkyNode<CargoShip> stemp = ptemp.getContents().getDockedShips().head;
            while (stemp != null) {
                selectedDelCShip.getItems().add(stemp.getContents());
                stemp = stemp.next;
            }
            selectedPort.getItems().add(ptemp.getContents());
            ptemp = ptemp.next;
        }
    }

    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}
