package com.example.ca1;

public class Container{

    public FunkyList<Pallet> containerPallets = new FunkyList<>();

    //Fields
    int code, size;

    public static Container head;

    //Getters
    public int getCode(){return code;}

    public int getSize(){return size;}

    //Setters
    public void setCode(int code) {this.code = code;}

    public void setSize(int size) {this.size = size;}
    public Container(int contID, int contSize){
        code=contID;
        size=contSize;
    }

//    Search function, allows user to search through the list of containers by code
public static Container getContainerByCode(int value) {
    FunkyList<Port>.FunkyNode<Port> ptemp = Port.portsList.head;

    // Check through ports
    while (ptemp != null) {
        // Check ships in port
        FunkyList<CargoShip>.FunkyNode<CargoShip> stemp = ptemp.getContents().dockedShips.head;
        while (stemp != null) {
            // Check containers in ship
            FunkyList<Container>.FunkyNode<Container> ctemp = stemp.getContents().shipContainers.head;
            while (ctemp != null && ctemp.getContents().getCode() != value) {
                ctemp = ctemp.next;
            }

            // Return container if code matches
            if (ctemp != null) {
                return ctemp.getContents();
            }

            stemp = stemp.next;
        }

        // After checking ships, try next port
        ptemp = ptemp.next;
    }

    // Return null if no container with the specified code is found
    return null;
}

    public String toString() {
        return "Container Code: " + code + ", Container Size: " + size;
    }

    public void addPallet(Pallet pal){
        containerPallets.addElement(pal);
    }

    public FunkyList<Container> getShipContainers() {
        CargoShip temp = new CargoShip("name", 1234, "flag", "picture");
        return temp.getShipContainers();
    }
}
