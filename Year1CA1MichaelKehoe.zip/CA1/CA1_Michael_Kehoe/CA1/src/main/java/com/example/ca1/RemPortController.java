package com.example.ca1;

import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceBox;
import java.io.IOException;

import static com.example.ca1.Port.portsList;

public class RemPortController {

    public ChoiceBox<Port> selectedDelPort;

    public void delPort(ActionEvent actionEvent) {
        Port selectedPort = selectedDelPort.getValue();

        if (selectedPort != null) {
            portsList.remove(selectedPort);
            System.out.println("Port '" + selectedPort.getPort() + "' deleted.");
            selectedDelPort.getItems().remove(selectedPort);
        } else {
            System.out.println("No port selected.");
        }
    }

    public void initialize() {
        FunkyList<Port>.FunkyNode<Port> ptemp = portsList.head;
        while (ptemp != null) {
            selectedDelPort.getItems().add(ptemp.getContents());
            ptemp = ptemp.next;
        }
    }

    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}
