package com.example.ca1;

import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;

public class AddCargoShipController {
//Fields, Choicebox for class
    public TextField cargoShipName;
    public TextField cargoShipID;
    public TextField cargoShipFlagState;
    public TextField cargoShipPic;
    public ChoiceBox<String> selectedPort;



//Creates a cargoship within a selected port
    public void CreateCargoShip(ActionEvent actionEvent) {
        CargoShip cShip1 = new CargoShip(cargoShipName.getText(), Integer.parseInt(cargoShipID.getText()), cargoShipFlagState.getText(), cargoShipPic.getText());
        FunkyList<Port>.FunkyNode<Port> temp = Port.portsList.head;
        while (temp != null && !temp.getContents().getPort().equals(selectedPort.getValue()))
            temp = temp.next;
        if (temp != null)
            temp.getContents().dockedShips.addElement(cShip1);
    }

    //Loads the list of ports into the dropdown menu in the application

    public void initialize() {
        FunkyList<Port>.FunkyNode<Port> ptemp = Port.portsList.head;
        while (ptemp != null) {
            selectedPort.getItems().add(ptemp.getContents().getPort());
            ptemp = ptemp.next;
        }
    }

//returns user to main menu
    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}
