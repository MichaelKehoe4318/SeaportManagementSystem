package com.example.ca1;

import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;

public class AddContainerController {

    //Fields, Choiceboxes
    public TextField contID;
    public TextField contSize;
    public ChoiceBox<String> selectedCShip;
    public ChoiceBox<String> selectedPort;

    //Creates a container within either a selected Port or cargoship
    public void CreateContainer(ActionEvent actionEvent) {
        Container cont1 = new Container(Integer.parseInt(contID.getText()), Integer.parseInt(contSize.getText()));
        CargoShip ship=getCargoShipByName(selectedCShip.getValue());
        assert ship != null;
        ship.shipContainers.addElement(cont1);
    }

    //Returns a cargoship by name, search function
    private CargoShip getCargoShipByName(String value) {
        FunkyList<Port>.FunkyNode<Port> ptemp=Port.portsList.head;
        while(ptemp!=null) {
            FunkyList<CargoShip>.FunkyNode<CargoShip> temp = ptemp.getContents().dockedShips.head;
            while (temp != null && !temp.getContents().getShipName().equals(value))
                temp = temp.next;
            if (temp != null)
                return temp.getContents();
            ptemp=ptemp.next;
        }
        return null;
    }

    //Fills a dropdown with the list of ports
    public void initialize() {
        FunkyList<Port>.FunkyNode<Port> ptemp=Port.portsList.head;
        while(ptemp!=null) {
            selectedPort.getItems().add(ptemp.getContents().getPort());
            ptemp=ptemp.next;
        }
    }
//Alerts the system that a port has been selected, and to allow the Cargoships dropdown to appear
    public void portSelected(ActionEvent actionEvent) {
        Port p =Port.getPortByName(selectedPort.getValue());
        selectedCShip.getItems().clear();
        FunkyList<CargoShip>.FunkyNode<CargoShip> ptemp=p.dockedShips.head;
        while(ptemp!=null) {
           selectedCShip.getItems().add(ptemp.getContents().getShipName());
            ptemp=ptemp.next;
        }
    }
//returns user to main menu
    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}
