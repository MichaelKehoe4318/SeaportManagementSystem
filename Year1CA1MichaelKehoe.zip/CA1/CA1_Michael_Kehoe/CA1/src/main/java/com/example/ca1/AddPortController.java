package com.example.ca1;

import javafx.event.ActionEvent;
import javafx.scene.control.TextField;

import java.io.IOException;

public class AddPortController {

    //Fields
    public TextField portCountry;
    public TextField portCode;
    public TextField portName;

    //Creates port within the list of ports
    public void CreatePort(ActionEvent actionEvent) {
        Port port1 = new Port(portName.getText(), Integer.parseInt(portCode.getText()), portName.getText());
        Port.portsList.addElement(port1);
        HelloApplication.showPorts();
    }

    //Returns user to main menu
    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}
