package com.example.ca1;

import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;

import java.io.IOException;

public class SmartAddSystemController {
    //Fields for every input option
    public ChoiceBox<String> objectToAdd;
    public TextField nameField;
    public TextField codeField;
    public TextField sizeField;
    public TextField countryField;
    public TextField goodsField;
    public Button addButton;

    public void initialize() {
        objectToAdd.getItems().addAll("Port", "CargoShip", "Container", "Pallet");
    }

    // Handles adding the object based on the selected type
    public void addObject(ActionEvent actionEvent) {
        String selectedType = objectToAdd.getValue();
        if (selectedType == null) {
            return;
        }

        // Get inputs from text fields
        String name = nameField.getText();
        String country = countryField.getText();
        String goods = goodsField.getText();
        int code = Integer.parseInt(codeField.getText());
        int size = Integer.parseInt(sizeField.getText());

        switch (selectedType) {
            case "Port" -> addPort(name, code, country);
            case "CargoShip" -> addCargoShip(name, code);
            case "Container" -> addContainer(code, size);
            case "Pallet" -> addPallet(goods, size, code);
            default -> System.out.println("Invalid selection");
        }
    }

    // Adds a new Port if selected
    private void addPort(String name, int code, String country) {
        Port newPort = new Port(name, code, country);
        Port.portsList.addElement(newPort);
        System.out.println("Port added: " + newPort);
    }

    // Adds a new CargoShip if selected
    private void addCargoShip(String name, int identifier) {
        CargoShip newShip = new CargoShip(name, identifier, "Default Flag", "Default Picture");
        // This example assumes CargoShips are added to a global list
        // Modify as needed if there are specific ports or lists
        Port.portsList.head.getContents().dockedShips.addElement(newShip);
        System.out.println("CargoShip added: " + newShip);
    }

    // Adds a new Container if selected
    private void addContainer(int code, int size) {
        Container newContainer = new Container(code, size);
        // Adding containers to all ships for demo purposes; adjust as needed
        FunkyList<Port>.FunkyNode<Port> portNode = Port.portsList.head;
        while (portNode != null) {
            FunkyList<CargoShip>.FunkyNode<CargoShip> shipNode = portNode.getContents().getDockedShips().head;
            while (shipNode != null) {
                shipNode.getContents().addContainer(newContainer);
                shipNode = shipNode.next;
            }
            portNode = portNode.next;
        }
        System.out.println("Container added: " + newContainer);
    }

    // Adds a new Pallet if selected
    private void addPallet(String goods, int size, int code) {
        Pallet newPallet = new Pallet(goods, 0, 0, 0, size);
        // Adding pallets to all containers
        FunkyList<Port>.FunkyNode<Port> portNode = Port.portsList.head;
        while (portNode != null) {
            FunkyList<CargoShip>.FunkyNode<CargoShip> shipNode = portNode.getContents().getDockedShips().head;
            while (shipNode != null) {
                FunkyList<Container>.FunkyNode<Container> containerNode = shipNode.getContents().getShipContainers().head;
                while (containerNode != null) {
                    containerNode.getContents().addPallet(newPallet);
                    containerNode = containerNode.next;
                }
                shipNode = shipNode.next;
            }
            portNode = portNode.next;
        }
        System.out.println("Pallet added: " + newPallet);
    }

    public void goHome(ActionEvent nactionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}

