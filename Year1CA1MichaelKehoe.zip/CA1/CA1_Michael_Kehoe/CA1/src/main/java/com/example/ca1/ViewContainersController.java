package com.example.ca1;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import java.io.IOException;

public class ViewContainersController {
    public ListView viewContainers;
    public Button homeButton;

    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }

    public void initialize() {
        FunkyList<Port>.FunkyNode<Port> ptemp = Port.portsList.head;
        while (ptemp != null) {
            FunkyList<CargoShip>.FunkyNode<CargoShip> ctemp = ptemp.getContents().dockedShips.head;
            while (ctemp != null) {
                FunkyList<Container>.FunkyNode<Container> contemp = ctemp.getContents().shipContainers.head;
                while (contemp != null) {
                    viewContainers.getItems().add(contemp.getContents());
                    contemp = contemp.next;
                }
                ctemp = ctemp.next;
            }
            ptemp = ptemp.next;
        }
    }
}