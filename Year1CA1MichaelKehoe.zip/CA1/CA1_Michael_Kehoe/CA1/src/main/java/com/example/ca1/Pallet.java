package com.example.ca1;

public class Pallet {

    public FunkyList<Pallet> palletList = new FunkyList<>();
    // Fields
    String goods;
    int quantity, value, weight, totSize;

    public static Pallet head;

    // Getters
    public String getGoods() {
        return goods;}

    public int getQuantity() {
        return quantity;}

    public int getValue() {
        return value;}

    public int getWeight() {
        return weight;}

    public int getTotSize() {
        return totSize;}

    // Setters
    public void setGoods(String goods) {
        this.goods = goods;}

    public void setQuantity(int quantity) {
        this.quantity = quantity;}

    public void setValue(int value) {
        this.value = value;}

    public void setWeight(int weight) {
        this.weight = weight;}

    public void setTotSize(int totSize) {
        this.totSize = totSize;}

    public Pallet(String palGoods, int palQuantity, int palValue, int palWeight, int contSize) {
        this.goods = palGoods;
        this.quantity = palQuantity;
        this.value = palValue;
        this.weight = palWeight;
        this.totSize = contSize;
    }

    public String toString() {
        return "Goods: " + goods + " Quantity: " + quantity + ", Weight: " + weight + ", Value: " + value + ", Total Size: " + totSize;
    }
}
