package com.example.ca1;

public class Port {

    //Fields
    String name,country;
    int pCode;

    public static Port head;

    public FunkyList<CargoShip> dockedShips = new FunkyList<>();

    public static FunkyList<CargoShip> shipsAtSea = new FunkyList<>();

    public static FunkyList<Port> portsList = new FunkyList<>();

    public static FunkyList<Container> shoreContainer = new FunkyList<>();

    public Port(String name,int code, String cntry){
        this.name=name;
        pCode=code;
        country=cntry;
    }

    //Getters
    public String getPort(){return name;}

    public int getCode(){return pCode;}

    public String getCountry(){return country;}

    public FunkyList<CargoShip> getDockedShips() {
        return dockedShips;
    }

    //Setters
    public void setName(String name){this.name=name;}

    public void setPCode(int code){this.pCode=code;}

    public void setCountry(String country){this.country=country;}

    //adds port to the list of ports
    public void addPort(Port po) {
   Port.portsList.addElement(po);
    }

    //Removes ship from the "at sea" list, adds it to the current port's list of ships
    public void dockShip(CargoShip shipToDock) {
        shipsAtSea.remove(shipToDock);
        dockedShips.addElement(shipToDock);
    }
    //Removes ship from port, adds it to the ships "at sea"
    public void launchShip(CargoShip shipToLaunch){
        dockedShips.remove(shipToLaunch);
        shipsAtSea.addElement(shipToLaunch);
    }

    public void addContainer(Container targetCont){
        shoreContainer.addElement(targetCont);
    }

    public void deleteShip(CargoShip delShip){
        dockedShips.remove(delShip);
    }


    //Search function, allows the user to search for a port using the port name
    public static Port getPortByName(String value) {
        FunkyList<Port>.FunkyNode<Port> temp = portsList.head;
        while (temp != null) {
            if (temp.getContents().getPort().equals(value)) {
                return temp.getContents();
            }
            temp = temp.next;
        }
        return null;
    }


    //Removes port from list of ports
    public void deletePort(Port delPort){
        portsList.remove(delPort);
    }

    public String toString(){return "Port name:" +name+",Port Code:"+pCode+", Country:"+country;
    }
}
