package com.example.ca1;

import javafx.event.ActionEvent;

import java.io.IOException;

public class MainMenuController {
//Create sceneswaps
    public void swapCreatePort(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("AddPortController.fxml");
    }
    public void swapCreateCShip(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("AddCargoShipController.fxml");
    }
    public void swapCreateCont(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("AddContainerController.fxml");
    }
    public void swapCreatePallet(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("AddPalletController.fxml");
    }

// View Sceneswaps
    public void swapViewPorts(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("ViewPortsController.fxml");
    }
    public void swapViewCShips(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("ViewCargoShipsController.fxml");
    }
    public void swapViewCont(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("ViewContainersController.fxml");
    }
    public void swapViewPallets(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("ViewPalletsController.fxml");
    }

    //Remove sceneswaps
    public void swapRemovePort(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("RemPortController.fxml");
    }
    public void swapRemoveCShip(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("RemCargoShipController.fxml");
    }
    public void swapRemoveCont(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("RemContainerController.fxml");
    }
    public void swapRemovePallet(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("RemPalletController.fxml");
    }

    //Extras Menu sceneswap
    public void swapExtrasMenu(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("ExtrasMenuController.fxml");
    }
}
