package com.example.ca1;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.io.IOException;

public class SearchSystemController {

    //Fields
    public TextField searchTarget;
    public ListView<String> searchResults;
    public Button searchButton;

    // Search system
    public void SearchFunction(ActionEvent actionEvent) {
        // Get search term
        String searchTerm = searchTarget.getText();

        searchResults.getItems().clear(); // Clear previous results

        // Check through ports list
        FunkyList<Port>.FunkyNode<Port> portNode = Port.portsList.head;
        while (portNode != null) {
            Port port = portNode.getContents();

            // Check for any matches
            if (port.getPort().equals(searchTerm)) {
                searchResults.getItems().add("Port Found: " + port.getPort());
                searchResults.getItems().add(port.toString());
                return;
            }

            // Traverse the list of docked ships within the port
            FunkyList<CargoShip>.FunkyNode<CargoShip> shipNode = port.getDockedShips().head;
            while (shipNode != null) {
                CargoShip ship = shipNode.getContents();

                // Check if the search term matches the cargo ship name
                if (ship.getShipName().equals(searchTerm)) {
                    searchResults.getItems().add("Cargo Ship Found: " + ship.getShipName());
                    searchResults.getItems().add(ship.toString());
                    return;
                }

                // Traverse the list of containers within the cargo ship
                FunkyList<Container>.FunkyNode<Container> containerNode = ship.getShipContainers().head;
                while (containerNode != null) {
                    Container container = containerNode.getContents();

                    // Check if the search term matches the container code
                    if (String.valueOf(container.getCode()).equals(searchTerm)) {
                        searchResults.getItems().add("Container Found: " + container.getCode());
                        searchResults.getItems().add(container.toString());
                        return;
                    }

                    // Traverse the list of pallets within the container
                    FunkyList<Pallet>.FunkyNode<Pallet> palletNode = container.containerPallets.head;
                    while (palletNode != null) {
                        Pallet pallet = palletNode.getContents();

                        // Check if the search term matches the pallet's goods
                        if (pallet.getGoods().equals(searchTerm)) {
                            searchResults.getItems().add("Pallet Found: " + pallet.getGoods());
                            searchResults.getItems().add(pallet.toString());
                            return;
                        }

                        palletNode = palletNode.next;
                    }

                    containerNode = containerNode.next;
                }

                shipNode = shipNode.next;
            }

            // Traverse the list of shore containers within the port
            FunkyList<Container>.FunkyNode<Container> shoreContainerNode = Port.shoreContainer.head;
            while (shoreContainerNode != null) {
                Container shoreContainer = shoreContainerNode.getContents();

                // Check if the search term matches the shore container code
                if (String.valueOf(shoreContainer.getCode()).equals(searchTerm)) {
                    searchResults.getItems().add("Shore Container Found: " + shoreContainer.getCode());
                    searchResults.getItems().add(shoreContainer.toString());
                    return;
                }

                // Traverse the list of pallets within the shore container
                FunkyList<Pallet>.FunkyNode<Pallet> palletNode = shoreContainer.containerPallets.head;
                while (palletNode != null) {
                    Pallet pallet = palletNode.getContents();

                    // Check if the search term matches the pallet's goods
                    if (pallet.getGoods().equals(searchTerm)) {
                        searchResults.getItems().add("Pallet Found: " + pallet.getGoods());
                        searchResults.getItems().add(pallet.toString());
                        return;
                    }

                    palletNode = palletNode.next;
                }

                shoreContainerNode = shoreContainerNode.next;
            }

            portNode = portNode.next;
        }

        // If no match is found, notify the user
        searchResults.getItems().add("No match found for: " + searchTerm);
    }

    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}
