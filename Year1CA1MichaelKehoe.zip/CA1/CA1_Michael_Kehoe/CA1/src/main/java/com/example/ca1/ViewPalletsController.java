package com.example.ca1;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;

import java.io.IOException;

public class ViewPalletsController {
    public ListView viewPallets;
    public Button homeButton;

    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }

    public void initialize() {
        FunkyList<Port>.FunkyNode<Port> ptemp = Port.portsList.head;
        while (ptemp != null) {
            FunkyList<CargoShip>.FunkyNode<CargoShip> stemp = ptemp.getContents().dockedShips.head;
            while (stemp != null) {
                FunkyList<Container>.FunkyNode<Container> ctemp = stemp.getContents().shipContainers.head;
                while (ctemp != null) {
                    FunkyList<Pallet>.FunkyNode<Pallet> pltemp = ctemp.getContents().containerPallets.head;
                    while (pltemp != null) {
                        viewPallets.getItems().add(pltemp.getContents());
                        pltemp = pltemp.next;
                    }
                    ctemp = ctemp.next;
                }
                stemp = stemp.next;
            }
        ptemp = ptemp.next;
        }
    }
}