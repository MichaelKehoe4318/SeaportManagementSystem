package com.example.ca1;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class HelloApplication extends Application {
//    public void start(Stage stage) throws IOException {
//        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("AddContainerController.fxml"));
//        Scene scene = new Scene(fxmlLoader.load());
//        stage.setTitle("Shipping Management System");
//        stage.setScene(scene);
//        stage.show();
//    }

    //Start begins the program, and boots the main menu controller before any other scene
    private static Stage stage1;
    @Override
public void start(Stage stage1) throws IOException {
    HelloApplication.stage1 = stage1;
    changeScene("MainMenuController.fxml");
}

//changeScene swaps and reloads the scene with another to swap them.
public static void changeScene(String sceneSwap) throws IOException {
    Parent screen = FXMLLoader.load(
            Objects.requireNonNull(HelloApplication.class.getResource(sceneSwap)));

            Scene scene = new Scene(screen);
            stage1.setScene(scene);
            stage1.show();
}


    public static void main(String[] args) {
        launch();
    }

    //Show methods display the contents of a list within the console for testing purposes
    public static void showPorts() {
        Port temp = Port.head;
        while (temp != null) {
            System.out.println(temp);
            temp = Port.head;
        }
    }

    public static void showCargoShips(){
        CargoShip temp = CargoShip.head;
        while(temp!=null){
            System.out.println(temp);
            temp= CargoShip.head;
        }
    }

    public static void showContainers(){
        Container temp = Container.head;
        while(temp!=null){
            System.out.println(temp);
            temp= Container.head;
        }
    }

    public static void showPallets(){
        Pallet temp = Pallet.head;
        while(temp!=null){
            System.out.println(temp);
            temp= Pallet.head;
        }
    }
}