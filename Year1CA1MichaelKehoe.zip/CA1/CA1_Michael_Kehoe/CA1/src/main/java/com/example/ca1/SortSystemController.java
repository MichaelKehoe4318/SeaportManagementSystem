package com.example.ca1;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortSystemController {

    public ListView<String> sortDisplay;
    public Button sortButton;
    public ChoiceBox<String> listToSort;

    public void initialize() {
        listToSort.getItems().addAll("Ports", "CargoShips", "Containers", "Pallets");
    }

    // Sorts the list alphabetically
    public void sortAll(ActionEvent actionEvent) {
        String selectedList = listToSort.getValue();

        if (selectedList == null) {
            return;
        }
        // Sort based on selection
        List<String> sortedList = switch (selectedList) {
            case "Ports" -> getPortNames();
            case "CargoShips" -> getCargoShipNames();
            case "Containers" -> getContainerCodes();
            case "Pallets" -> getPalletGoods();
            default -> new ArrayList<>();
        };

        // Sort list
        Collections.sort(sortedList);

        // Display list in the ListView
        sortDisplay.getItems().setAll(sortedList);
    }

    // Port names
    private List<String> getPortNames() {
        List<String> portNames = new ArrayList<>();
        FunkyList<Port>.FunkyNode<Port> portNode = Port.portsList.head;

        while (portNode != null) {
            portNames.add(portNode.getContents().getPort());
            portNode = portNode.next;
        }

        return portNames;
    }

    // CargoShip names
    private List<String> getCargoShipNames() {
        List<String> cargoShipNames = new ArrayList<>();
        FunkyList<Port>.FunkyNode<Port> portNode = Port.portsList.head;

        while (portNode != null) {
            FunkyList<CargoShip>.FunkyNode<CargoShip> shipNode = portNode.getContents().getDockedShips().head;
            while (shipNode != null) {
                cargoShipNames.add(shipNode.getContents().getShipName());
                shipNode = shipNode.next;
            }
            portNode = portNode.next;
        }

        return cargoShipNames;
    }

    // Container codes
    private List<String> getContainerCodes() {
        List<String> containerCodes = new ArrayList<>();
        FunkyList<Port>.FunkyNode<Port> portNode = Port.portsList.head;

        while (portNode != null) {
            FunkyList<CargoShip>.FunkyNode<CargoShip> shipNode = portNode.getContents().getDockedShips().head;
            while (shipNode != null) {
                FunkyList<Container>.FunkyNode<Container> containerNode = shipNode.getContents().getShipContainers().head;
                while (containerNode != null) {
                    containerCodes.add(String.valueOf(containerNode.getContents().getCode()));
                    containerNode = containerNode.next;
                }
                shipNode = shipNode.next;
            }
            portNode = portNode.next;
        }

        return containerCodes;
    }

    // Pallet goods
    private List<String> getPalletGoods() {
        List<String> palletGoods = new ArrayList<>();
        FunkyList<Port>.FunkyNode<Port> portNode = Port.portsList.head;
        while (portNode != null) {
            FunkyList<CargoShip>.FunkyNode<CargoShip> shipNode = portNode.getContents().getDockedShips().head;
            while (shipNode != null) {
                FunkyList<Container>.FunkyNode<Container> containerNode = shipNode.getContents().getShipContainers().head;
                while (containerNode != null) {
                    FunkyList<Pallet>.FunkyNode<Pallet> palletNode = containerNode.getContents().containerPallets.head;
                    while (palletNode != null) {
                        palletGoods.add(palletNode.getContents().getGoods());
                        palletNode = palletNode.next;
                    }
                    containerNode = containerNode.next;
                }
                shipNode = shipNode.next;
            }
            portNode = portNode.next;
        }

        return palletGoods;
    }

    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}
