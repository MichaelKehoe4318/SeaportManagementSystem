package com.example.ca1;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;

import java.io.IOException;

public class ViewCargoShipsController {
    //Fields

    //This and all other view[List] classes display a window that gets filled by initialise, allowing the user to view the corresponding list
    public ListView viewCargoShips;
    public Button homeButton;

    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }

    public void initialize() {
        FunkyList<Port>.FunkyNode<Port> ptemp=Port.portsList.head;
        while(ptemp!=null) {
            FunkyList<CargoShip>.FunkyNode<CargoShip> temp= ptemp.getContents().dockedShips.head;
            while(temp!=null) {
                viewCargoShips.getItems().add(temp.getContents());
                temp = temp.next;
            }
            ptemp=ptemp.next;
        }
    }
}
