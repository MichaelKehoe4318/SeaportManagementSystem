package com.example.ca1;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SaveLoadController {

    public TextField filePathField;
    public Button saveButton;
    public Button loadButton;

    // Saves the data from all lists to the specified file
    public void saveData(ActionEvent actionEvent) {
        String filePath = filePathField.getText();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            // Save Ports
            writer.write("Ports\n");
            for (Port port : getAllPorts()) {
                writer.write(String.format("Port,%s,%d,%s%n", port.getPort(), port.getCode(), port.getCountry()));
            }
            // Save CargoShips
            writer.write("CargoShips\n");
            for (CargoShip ship : getAllCargoShips()) {
                writer.write(String.format("CargoShip,%s,%d%n", ship.getShipName(), ship.getId()));
            }
            // Save Containers
            writer.write("Containers\n");
            for (Container container : getAllContainers()) {
                writer.write(String.format("Container,%d,%d%n", container.getCode(), container.getSize()));
            }
            // Save Pallets
            writer.write("Pallets\n");
            for (Pallet pallet : getAllPallets()) {
                writer.write(String.format("Pallet,%s,%d,%d,%d,%d%n", pallet.getGoods(), pallet.getQuantity(), pallet.getValue(), pallet.getWeight(), pallet.getTotSize()));
            }

            System.out.println("Data saved to " + filePath);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Save Failed");
        }
    }

    // Loads data from targeted file
    public void loadData(ActionEvent actionEvent) {
        String filePath = filePathField.getText();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                switch (line) {
                    case "Ports" -> loadPorts(reader);
                    case "CargoShips" -> loadCargoShips(reader);
                    case "Containers" -> loadContainers(reader);
                    case "Pallets" -> loadPallets(reader);
                }
            }
            System.out.println("Data loaded:" + filePath);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Load Failed");
        }
    }

    // Load Ports from the reader
    private void loadPorts(BufferedReader reader) throws IOException {
        String line;
        while ((line = reader.readLine()) != null && !line.isEmpty()) {
            String[] parts = line.split(",");
            if (parts.length == 4) {
                String name = parts[1];
                int code = Integer.parseInt(parts[2]);
                String country = parts[3];
                Port port = new Port(name, code, country);
                Port.portsList.addElement(port);
            }
        }
    }

    // Load CargoShips from reader
    private void loadCargoShips(BufferedReader reader) throws IOException {
        String line;
        while ((line = reader.readLine()) != null && !line.isEmpty()) {
            String[] parts = line.split(",");
            if (parts.length == 3) {
                String name = parts[1];
                int id = Integer.parseInt(parts[2]);
                CargoShip ship = new CargoShip(name, id, "Flag", "Picture");
                Port.portsList.head.getContents().dockedShips.addElement(ship);
            }
        }
    }

    // Load Containers from reader
    private void loadContainers(BufferedReader reader) throws IOException {
        String line;
        while ((line = reader.readLine()) != null && !line.isEmpty()) {
            String[] parts = line.split(",");
            if (parts.length == 3) {
                int code = Integer.parseInt(parts[1]);
                int size = Integer.parseInt(parts[2]);
                Container container = new Container(code, size);
                FunkyList<Port>.FunkyNode<Port> portNode = Port.portsList.head;
                while (portNode != null) {
                    FunkyList<CargoShip>.FunkyNode<CargoShip> shipNode = portNode.getContents().getDockedShips().head;
                    while (shipNode != null) {
                        shipNode.getContents().addContainer(container);
                        shipNode = shipNode.next;
                    }
                    portNode = portNode.next;
                }
            }
        }
    }

    // Load Pallets from reader
    private void loadPallets(BufferedReader reader) throws IOException {
        String line;
        while ((line = reader.readLine()) != null && !line.isEmpty()) {
            String[] parts = line.split(",");

            // Check if the number of parts matches format
            if (parts.length == 5) {
                try {
                    String goods = parts[0]; // Index 0 for goods
                    int quantity = Integer.parseInt(parts[1]); // Index 1 for quantity
                    int value = Integer.parseInt(parts[2]); // Index 2 for value
                    int weight = Integer.parseInt(parts[3]); // Index 3 for weight
                    int size = Integer.parseInt(parts[4]); // Index 4 for size
                    // Create a new Pallet instance
                    Pallet pallet = new Pallet(goods, quantity, value, weight, size);
                    addPalletToAllContainers(pallet);
                } catch (NumberFormatException e) {
                    System.err.println("Error with pallet data: " + e.getMessage());
                }
            } else {
                System.err.println("Error: " + line);
            }
        }
    }

    private void addPalletToAllContainers(Pallet pallet) {
        FunkyList<Port>.FunkyNode<Port> portNode = Port.portsList.head;
        while (portNode != null) {
            FunkyList<CargoShip>.FunkyNode<CargoShip> shipNode = portNode.getContents().getDockedShips().head;
            while (shipNode != null) {
                FunkyList<Container>.FunkyNode<Container> containerNode = shipNode.getContents().getShipContainers().head;
                while (containerNode != null) {
                    containerNode.getContents().addPallet(pallet);
                    containerNode = containerNode.next;
                }
                shipNode = shipNode.next;
            }
            portNode = portNode.next;
        }
    }


    // Method to retrieve all Ports
    private List<Port> getAllPorts() {
        List<Port> ports = new ArrayList<>();
        FunkyList<Port>.FunkyNode<Port> node = Port.portsList.head;
        while (node != null) {
            ports.add(node.getContents());
            node = node.next;
        }
        return ports;
    }
    private List<CargoShip> getAllCargoShips() {
        List<CargoShip> ships = new ArrayList<>();
        FunkyList<Port>.FunkyNode<Port> portNode = Port.portsList.head;
        while (portNode != null) {
            FunkyList<CargoShip>.FunkyNode<CargoShip> shipNode = portNode.getContents().getDockedShips().head;
            while (shipNode != null) {
                ships.add(shipNode.getContents());
                shipNode = shipNode.next;
            }
            portNode = portNode.next;
        }
        return ships;
    }
    private List<Container> getAllContainers() {
        List<Container> containers = new ArrayList<>();
        FunkyList<Port>.FunkyNode<Port> portNode = Port.portsList.head;
        while (portNode != null) {
            FunkyList<CargoShip>.FunkyNode<CargoShip> shipNode = portNode.getContents().getDockedShips().head;
            while (shipNode != null) {
                FunkyList<Container>.FunkyNode<Container> containerNode = shipNode.getContents().getShipContainers().head;
                while (containerNode != null) {
                    containers.add(containerNode.getContents());
                    containerNode = containerNode.next;
                }
                shipNode = shipNode.next;
            }
            portNode = portNode.next;
        }
        return containers;
    }
    private List<Pallet> getAllPallets() {
        List<Pallet> pallets = new ArrayList<>();
        FunkyList<Port>.FunkyNode<Port> portNode = Port.portsList.head;
        while (portNode != null) {
            FunkyList<CargoShip>.FunkyNode<CargoShip> shipNode = portNode.getContents().getDockedShips().head;
            while (shipNode != null) {
                FunkyList<Container>.FunkyNode<Container> containerNode = shipNode.getContents().getShipContainers().head;
                while (containerNode != null) {
                    FunkyList<Pallet>.FunkyNode<Pallet> palletNode = containerNode.getContents().containerPallets.head;
                    while (palletNode != null) {
                        pallets.add(palletNode.getContents());
                        palletNode = palletNode.next;
                    }
                    containerNode = containerNode.next;
                }
                shipNode = shipNode.next;
            }
            portNode = portNode.next;
        }
        return pallets;
    }

    // Returns the user to the main menu
    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}

