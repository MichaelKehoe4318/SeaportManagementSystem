package com.example.ca1;

import javafx.event.ActionEvent;

import java.io.IOException;

public class ExtrasMenuController {

    //Extras Main menu, acessed from the main menu, contains buttons to go to all functions listed below-

    //Returns user to main menu
    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }

    public void swapSearchMenu(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("SearchSystemController.fxml");
    }

    public void SwapSortMenu(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("SortSystemController.fxml");
    }

    public void swapSmartAddMenu(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("SmartAddSystemController.fxml");
    }

    public void swapSaveLoadMenu(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("");
    }

    //Instead of having it's own page, the full facility reset is located here
    public void clearAllLists(ActionEvent actionEvent) {
        Port.portsList.clear();
        Port.shoreContainer.clear();
        Port.shipsAtSea.clear();

    }
}
