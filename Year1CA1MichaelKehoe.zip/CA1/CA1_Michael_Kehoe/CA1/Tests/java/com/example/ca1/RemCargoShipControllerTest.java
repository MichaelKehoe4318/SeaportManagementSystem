package com.example.ca1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RemCargoShipControllerTest {

    @Test
    void delCShip() {
    }

    @Test
    void remAllCShips() {
    }
}