package com.example.ca1;

import javafx.scene.control.TextField;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AddPortControllerTest {

    @Test
    void createPort() {
        var Port = new Port("name", 1234, "cntry");

    }
}

