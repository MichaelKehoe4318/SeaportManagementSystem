package com.example.ca1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PortTest {

    @Test
    void getPort() {
    }

    @Test
    void getCode() {
    }

    @Test
    void getCountry() {
    }

    @Test
    void getDockedShips() {
    }

    @Test
    void setName() {
    }

    @Test
    void setPCode() {
    }

    @Test
    void setCountry() {
    }

    @Test
    void addPort() {
    }

    @Test
    void dockShip() {
    }

    @Test
    void launchShip() {
    }

    @Test
    void addContainer() {
    }

    @Test
    void deleteShip() {
    }

    @Test
    void getPortByName() {
    }
}