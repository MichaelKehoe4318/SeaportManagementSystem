package com.example.ca1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RemPalletControllerTest {

    @Test
    void delPallet() {
    }

    @Test
    void remAllPallets() {
    }
}