package com.example.ca1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PalletTest {

    @Test
    void getGoods() {
    }

    @Test
    void getQuantity() {
    }

    @Test
    void getValue() {
    }

    @Test
    void getWeight() {
    }

    @Test
    void getTotSize() {
    }

    @Test
    void setGoods() {
    }

    @Test
    void setQuantity() {
    }

    @Test
    void setValue() {
    }

    @Test
    void setWeight() {
    }

    @Test
    void setTotSize() {
    }
}