package com.example.ca1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContainerTest {

    @Test
    void getCode() {
    }

    @Test
    void getSize() {
    }

    @Test
    void setCode() {
    }

    @Test
    void setSize() {
    }

    @Test
    void getContainerByCode() {
    }

    @Test
    void addPallet() {
    }

    @Test
    void getShipContainers() {
    }
}