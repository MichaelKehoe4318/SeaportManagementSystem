package com.example.ca1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AddPalletControllerTest {

    @Test
    void createPallet() {
    }

    @Test
    void getContainerByName() {
    }
}