package com.example.ca1;

import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AddContainerControllerTest {
    public TextField contID;
    public TextField contSize;
     public ChoiceBox<String> selectedCShip;

    @Test
    void createContainer() {

        assertEquals(contID, contSize);
    }
}