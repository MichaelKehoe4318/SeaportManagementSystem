package com.example.ca1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RemContainerControllerTest {

    @Test
    void delContainer() {
    }

    @Test
    void remAllContainers() {
    }
}