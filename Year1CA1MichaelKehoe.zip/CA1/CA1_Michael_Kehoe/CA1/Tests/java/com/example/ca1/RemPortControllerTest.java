package com.example.ca1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RemPortControllerTest {

    @Test
    void delPort() {
    }

    @Test
    void remAllPorts() {
    }
}