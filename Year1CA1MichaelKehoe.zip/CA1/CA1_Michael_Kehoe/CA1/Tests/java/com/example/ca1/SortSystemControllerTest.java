package com.example.ca1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SortSystemControllerTest {

    @Test
    void sortAll() {
    }
}