package com.example.ca1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CargoShipTest {

    @Test
    void getShipName() {
    }

    @Test
    void getId() {
    }

    @Test
    void getFlagState() {
    }

    @Test
    void getPic() {
    }

    @Test
    void getShipContainers() {
    }

    @Test
    void setName() {
    }

    @Test
    void setIdentifier() {
    }

    @Test
    void setFlagState() {
    }

    @Test
    void setPic() {
    }

    @Test
    void addContainer() {
    }

    @Test
    void getCargoShipByName() {
    }
}